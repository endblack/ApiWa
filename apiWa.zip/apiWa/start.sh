#!bin/bash
GREEN='\033[0;32m'
while : 
do
echo "iniciando no modo anti queda aguarde..."
    node app.js
    sleep 1

done
