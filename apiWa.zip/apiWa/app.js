const express = require("express")
const morgan = require("morgan")
const fs = require("fs")
const ms = require("ms")
const pms = require("parse-ms")
const {dados} = require("./dados")
const { exec } = require('child_process')
const app = express()
port = dados.porta

app.use(morgan("dev"))
app.use(express.json())
app.listen(port, () => {
  console.log("Api rodando na porta "+port)
})

function delay(t) {
  return new Promise(res => setTimeout(res, t*1000))
}

exec(`cat /etc/passwd | awk -F : '$3 >= 1000 {print $1}' | grep -v nobody | grep -v ubuntu | grep -v root | grep -v opc | grep -v snap_daemon > usuarios.txt`)
if(fs.existsSync("./token.txt")) {
  var rtoken =  fs.readFileSync("./token.txt").toString().replace(/\n/g, "").replace(/\r/g, "").replace(/\\r/g, "")
} else {
  var rtoken = require('crypto').randomBytes(50).toString('base64')
  fs.writeFileSync("./token.txt", rtoken)
}

function delay(t) {
  return new Promise(res => setTimeout(res, t*1000))
}
function ale(i) {
  if(!i) i = 10000000000000000000
  return Math.floor(Math.random()*(i+1))
}
app.get("/", (req, res) => {
  exec(`cat /etc/passwd | awk -F : '$3 >= 1000 {print $1}' | grep -v nobody | grep -v ubuntu | grep -v root | grep -v opc | grep -v snap_daemon > usuarios.txt`)
  res.status(200)
  res.json({msg: "online"})
})
app.get("/favicon.ico", (req, res) => {
  res.status(200)
  res.sendFile(__dirname+"/favicon.ico")
})
app.post("/criarlogin", async (req, res) => {
  exec(`cat /etc/passwd | awk -F : '$3 >= 1000 {print $1}' | grep -v nobody | grep -v ubuntu | grep -v root | grep -v opc | grep -v snap_daemon > usuarios.txt`)
  try {
  var {user} = req.body
  var {senha} = req.body
  var {token} = req.body
  var {dias} = req.body
  var {limite} = req.body
  
  var usuariosf = fs.readFileSync("./usuarios.txt").toString()
  usuarios = usuariosf.split("\n")
  
  if(!dias) dias = "31"
  if(!limite) limite = "1"
  if(!token) {
    res.status(400)
    res.json({msg: "Cade o token?"})
    return
  }
  if(token != rtoken) {
    res.status(403)
    res.json({msg: "token invalido", token})
    return
  }
  if(!user) {
    res.status(400)
    res.json({msg: "Cade o user?"})
    return
  }
  if(!senha) {
    res.status(400)
    res.json({msg: "Cade a senha?"})
    return
  }
  if(usuarios.includes(user) || user == "root") {
    res.status(200)
    res.json({msg: "jatem"})
    return
  }
  
  exec(`bash ./src/user.sh ${user} ${senha} ${dias} ${limite}`)
  if(fs.existsSync("/etc/v2ray/config.json")) {
    
  }
  atu()
  res.status(200)
  res.json({msg: "sucesso", user, senha, dias, limite})
  } catch (e) {
    console.log(e)
    res.status(500)
    res.json({msg: "Ocorreu um erro ao processar a solicitacao"})
    return
  }
})
app.post("/criarteste", async (req, res) => {
  exec(`cat /etc/passwd | awk -F : '$3 >= 1000 {print $1}' | grep -v nobody | grep -v ubuntu | grep -v root | grep -v opc | grep -v snap_daemon > usuarios.txt`)
  try {
  var {user} = req.body
  var {temp} = req.body
  var {token} = req.body
  
  var usuariosf = fs.readFileSync("./usuarios.txt").toString()
  usuarios = usuariosf.split("\n")
  
  //console.log(req.body)
  if(!token) {
    res.status(400)
    res.json({msg: "Cade o token?"})
    return
  }
  if(token != rtoken) {
    res.status(403)
    res.json({msg: "token invalido"})
    return
  }
  if(!user) {
    res.status(400)
    res.json({msg: "Cade o user?"})
    return
  }
  if(!temp) {
    res.status(400)
    res.json({msg: "Cade o tempo em min?"})
    return
  }
  if(usuarios.includes(user) || user == "root") {
    res.status(200)
    res.json({msg: "jatem"})
    return
  }
  fs.writeFileSync(__dirname+"/temp/"+user, ms(temp+"m")+Date.now())
  exec(`bash ./src/teste.sh ${user} ${temp}`)
  atu()
  res.status(200)
  res.json({msg: "sucesso", user, temp})
  } catch (e) {
    console.log(e)
    res.status(500)
    res.json({msg: "Ocorreu um erro ao processar a solicitacao"})
    return
  }
})
app.post("/renovar", async (req, res) => {
  exec(`cat /etc/passwd | awk -F : '$3 >= 1000 {print $1}' | grep -v nobody | grep -v ubuntu | grep -v root | grep -v opc | grep -v snap_daemon > usuarios.txt`)
  try {
  var {user} = req.body
  var {dias} = req.body
  var {token} = req.body
  
  var usuariosf = fs.readFileSync("./usuarios.txt").toString()
  usuarios = usuariosf.split("\n")
  
  if(!token) {
    res.status(400)
    res.json({msg: "Cade o token?"})
    return
  }
  if(token != rtoken) {
    res.status(403)
    res.json({msg: "token invalido"})
    return
  }
  if(!user) {
    res.status(400)
    res.json({msg: "Cade o user?"})
    return
  }
  if(!dias) {
    res.status(400)
    res.json({msg: "Cade os dias?"})
    return
  }
  if(!usuarios.includes(user) || user == "root") {
    res.status(200)
    res.json({msg: "naotem"})
    return
  }
  
  exec(`sh ./src/renovar.sh ${user} ${dias}`)
  atu()
  res.status(200)
  res.json({msg: "sucesso", user, dias})
  } catch (e) {
    console.log(e)
    res.status(500)
    res.json({msg: "Ocorreu um erro ao processar a solicitacao "})
    return
  }
})
app.post("/blockuser", async (req, res) => {
  exec(`cat /etc/passwd | awk -F : '$3 >= 1000 {print $1}' | grep -v nobody | grep -v ubuntu | grep -v root | grep -v opc | grep -v snap_daemon > usuarios.txt`)
  try {
  var {users} = req.body
  var {token} = req.body
  
  //var usuariosf = fs.readFileSync("./usuarios.txt").toString()
  //usuarios = usuariosf.split("\n")
  
  if(!token) {
    res.status(400)
    res.json({msg: "Cade o token?"})
    return
  }
  if(token != rtoken) {
    res.status(403)
    res.json({msg: "token invalido"})
    return
  }
  if(!users) {
    res.status(400)
    res.json({msg: "Cade o user?"})
    return
  }
  if(!Array.isArray(users)) {
    res.status(400)
    res.json({msg: "Os users tem que ser um array"})
    return
  }
  if(users.includes("root")) {
    res.status(403)
    res.json({msg: "Não pode conter o usuario root"})
    return
  }
  /*if(!usuarios.includes(user) || user == "root") {
    res.status(200)
    res.json({msg: "naotem"})
    return
  }*/
  for (var i = 0; i < users.length; i++) {
    exec(`sh ./src/blockuser.sh ${users[i]}`)
  }
  
  res.status(200)
  res.json({msg: "sucesso", users})
  } catch (e) {
    console.log(e)
    res.status(500)
    res.json({msg: "Ocorreu um erro ao processar a solicitacao "})
    return
  }
})
app.post("/deluser", async (req, res) => {
  exec(`cat /etc/passwd | awk -F : '$3 >= 1000 {print $1}' | grep -v nobody | grep -v ubuntu | grep -v root | grep -v opc | grep -v snap_daemon > usuarios.txt`)
  try {
  var {user} = req.body
  var {token} = req.body
 
  if(!token) {
    res.status(400)
    res.json({msg: "Cade o token?"})
    return
  }
  if(token != rtoken) {
    res.status(403)
    res.json({msg: "token invalido"})
    return
  }
  if(!user) {
    res.status(400)
    res.json({msg: "Cade o user?"})
    return
  }
  if(Array.isArray(user)) {
    if(user.includes("root")) {
      res.status
      res.json({msg: "Nao pode excluir o root"})
      return
    }
    for (var i = 0; i < user.length; i++) {
      exec(`bash ./src/deluser.sh ${user[i]}`)
    }
    atu()
    res.status(200)
    res.json({msg: "sucesso", user})
    return
  }
  
  var usuariosf = fs.readFileSync("./usuarios.txt").toString()
  usuarios = usuariosf.split("\n")
  
  if(!usuarios.includes(user) || user == "root") {
    res.status(200)
    res.json({msg: "naotem"})
    return
  }
  exec(`bash ./src/deluser.sh ${user}`)
  atu()
  res.status(200)
  res.json({msg: "sucesso", user})
  } catch (e) {
    console.log(e)
    res.status(500)
    res.json({msg: "Ocorreu um erro ao processar a solicitacao "})
    return
  }
})
app.post("/dblockuser", async (req, res) => {
  exec(`cat /etc/passwd | awk -F : '$3 >= 1000 {print $1}' | grep -v nobody | grep -v ubuntu | grep -v root | grep -v opc | grep -v snap_daemon > usuarios.txt`)
  try {
  var {users} = req.body
  var {token} = req.body
  
  //var usuariosf = fs.readFileSync("./usuarios.txt").toString()
  //usuarios = usuariosf.split("\n")
  
  if(!token) {
    res.status(400)
    res.json({msg: "Cade o token?"})
    return
  }
  if(token != rtoken) {
    res.status(403)
    res.json({msg: "token invalido"})
    return
  }
  if(!users) {
    res.status(400)
    res.json({msg: "Cade o user?"})
    return
  }
  if(!Array.isArray(users)) {
    res.status(400)
    res.json({msg: "Os users tem que ser um array"})
    return
  }
  if(users.includes("root")) {
    res.status(403)
    res.json({msg: "Não pode conter o usuario root"})
    return
  }
  /*if(!usuarios.includes(user) || user == "root") {
    res.status(200)
    res.json({msg: "naotem"})
    return
  }*/
  
  for (var i = 0; i < users.length; i++) {
    exec(`usermod -U ${users[i]}`)
  }
  
  res.status(200)
  res.json({msg: "sucesso", users})
  } catch (e) {
    console.log(e)
    res.status(500)
    res.json({msg: "Ocorreu um erro ao processar a solicitacao "})
    return
  }
})
app.post("/mudarlimite", async (req, res) => {
  exec(`cat /etc/passwd | awk -F : '$3 >= 1000 {print $1}' | grep -v nobody | grep -v ubuntu | grep -v root | grep -v opc | grep -v snap_daemon > usuarios.txt`)
  try {
  var {user} = req.body
  var {limite} = req.body
  var {token} = req.body
  
  var usuariosf = fs.readFileSync("./usuarios.txt").toString()
  usuarios = usuariosf.split("\n")
  
  if(!token) {
    res.status(400)
    res.json({msg: "Cade o token?"})
    return
  }
  if(token != rtoken) {
    res.status(403)
    res.json({msg: "token invalido"})
    return
  }
  if(!user) {
    res.status(400)
    res.json({msg: "Cade o user?"})
    return
  }
  if(!limite) {
    res.status(400)
    res.json({msg: "Cade o limite?"})
    return
  }
  if(!usuarios.includes(user) || user == "root") {
    res.status(200)
    res.json({msg: "naotem"})
    return
  }
  
  exec(`bash ./src/mudarlimite.sh ${user} ${limite}`)
  res.status(200)
  res.json({msg: "sucesso", user, limite})
  } catch (e) {
    console.log(e)
    res.status(500)
    res.json({msg: "Ocorreu um erro ao processar a solicitacao "})
    return
  }
})
app.post("/mudarsenha", async (req, res) => {
  exec(`cat /etc/passwd | awk -F : '$3 >= 1000 {print $1}' | grep -v nobody | grep -v ubuntu | grep -v root | grep -v opc | grep -v snap_daemon > usuarios.txt`)
  try {
  var {user} = req.body
  var {senha} = req.body
  var {token} = req.body
  
  var usuariosf = fs.readFileSync("./usuarios.txt").toString()
  usuarios = usuariosf.split("\n")
  
  if(!token) {
    res.status(400)
    res.json({msg: "Cade o token?"})
    return
  }
  if(token != rtoken) {
    res.status(403)
    res.json({msg: "token invalido"})
    return
  }
  if(!user) {
    res.status(400)
    res.json({msg: "Cade o user?"})
    return
  }
  if(!senha) {
    res.status(400)
    res.json({msg: "Cade a senha?"})
    return
  }
  if(!usuarios.includes(user) || user == "root") {
    res.status(200)
    res.json({msg: "naotem"})
    return
  }
  
  exec(`bash ./src/mudarsenha.sh ${user} ${senha}`)
  atu()
  res.status(200)
  res.json({msg: "sucesso", user, senha})
  } catch (e) {
    console.log(e)
    res.status(500)
    res.json({msg: "Ocorreu um erro ao processar a solicitacao "})
    return
  }
})
app.post("/users", async (req, res) => {
  exec(`cat /etc/passwd | awk -F : '$3 >= 1000 {print $1}' | grep -v nobody | grep -v ubuntu | grep -v root | grep -v opc | grep -v snap_daemon > usuarios.txt`)
  try {
  var {token} = req.body
  if(!token) {
    res.status(400)
    res.json({msg: "Cade o token?"})
    return
  }
  if(token != rtoken) {
    res.status(403)
    res.json({msg: "token invalido"})
    return
  }
  exec(`awk -F : '$3 >= 1000 { print $1 }' /etc/passwd`, (error, stdout, stderr) => {
    if(error) {
      console.log(error)
      res.status(500)
      res.json({msg: "erro"})
      return
    }
    if(stderr) {
      console.log(stderr)
      res.status(500)
      res.json({msg: "erro"})
      return
    }
    res.status(200)
    res.json({msg: "sucesso", info: stdout.split("\n")})
    return
  })
  } catch (e) {
    console.log(e)
    res.status(500)
    res.json({msg: "Ocorreu um erro ao processar a solicitacao "})
    return
  }
})
app.post("/infovps", async (req, res) => {
  exec(`cat /etc/passwd | awk -F : '$3 >= 1000 {print $1}' | grep -v nobody | grep -v ubuntu | grep -v root | grep -v opc | grep -v snap_daemon > usuarios.txt`)
  try {
  var {token} = req.body
  if(!token) {
    res.status(400)
    res.json({msg: "Cade o token?"})
    return
  }
  if(token != rtoken) {
    res.status(403)
    res.json({msg: "token invalido"})
    return
  }
  
  exec("bash ./src/infovps.sh", (error, stdout, stderr) => {
    if(error) {
      console.log(error)
      res.status(500)
      res.json({msg: "erro"})
      return
    }
    if(stderr) {
      console.log(stderr)
      res.status(500)
      res.json({msg: "erro"})
      return
    }
    res.status(200)
    res.json({msg: "sucesso", info: stdout})
    return
  })
  } catch (e) {
    console.log(e)
    res.status(500)
    res.json({msg: "Ocorreu um erro ao processar a solicitacao "})
    return
  }
})
app.post("/infousu", async (req, res) => {
  exec(`cat /etc/passwd | awk -F : '$3 >= 1000 {print $1}' | grep -v nobody | grep -v ubuntu | grep -v root | grep -v opc | grep -v snap_daemon > usuarios.txt`)
  try {
  var {token} = req.body
  if(!token) {
    res.status(400)
    res.json({msg: "Cade o token?"})
    return
  }
  if(token != rtoken) {
    res.status(403)
    res.json({msg: "token invalido"})
    return
  }
  
  exec("bash ./src/infousu.sh", (error, stdout, stderr) => {
    if(error) {
      console.log(error)
      res.status(500)
      res.json({msg: "erro"})
      return
    }
    if(stderr) {
      console.log(stderr)
      res.status(500)
      res.json({msg: "erro"})
      return
    }
    var info = []
    resul = stdout.split("#")
    //console.log(resul)
    for (var i = 0; i < resul.length-1; i++) {
      user = resul[i].split("|")[0].replace("\n", "")
      senha = resul[i].split("|")[1]
      limite = resul[i].split("|")[2]
      data = resul[i].split("|")[3]
      if(fs.existsSync(__dirname+"/temp/"+user)) {
        temps = fs.readFileSync(__dirname+"/temp/"+user).toString()
        exp = pms(Number(temps)-Date.now())
        exp = exp.days > 0 ? exp.days+" DIA'S" : exp.hours > 0 && exp.days == 0 ? exp.hours+":"+exp.minutes+" horas" : exp.minutes > 0 && exp.hours == 0 && exp.days == 0 ? exp.minutes+" min" : exp.seconds > 0 && exp.days == 0 && exp.minutes == 0 && exp.hours == 0 ? exp.seconds+" seg" : "venceu"
        data = exp
      }
      obj = {
        user,
        senha,
        limite,
        data
      }
      info.push(obj)
    }
    res.status(200)
    res.json({msg: "sucesso", info})
    return
  })
  } catch (e) {
    console.log(e)
    res.status(500)
    res.json({msg: "Ocorreu um erro ao processar a solicitacao "})
    return
  }
})
app.post("/onlines", async (req, res) => {
  exec(`cat /etc/passwd | awk -F : '$3 >= 1000 {print $1}' | grep -v nobody | grep -v ubuntu | grep -v root | grep -v opc | grep -v snap_daemon > usuarios.txt`)
  try {
  var {token} = req.body
  if(!token) {
    res.status(400)
    res.json({msg: "Cade o token?"})
    return
  }
  if(token != rtoken) {
    res.status(403)
    res.json({msg: "token invalido"})
    return
  }
  
  exec("bash ./src/useron.sh", (error, stdout, stderr) => {
    if(error) {
      console.log(error)
      res.status(500)
      res.json({msg: "erro"})
      return
    }
    if(stderr) {
      console.log(stderr)
      res.status(500)
      res.json({msg: "erro"})
      return
    }
    info = []
    console.log(stdout)
    console.log("#############")
    resul = stdout.split("#")
    console.log(resul)
    for (var i = 0; i < resul.length-1; i++) {
      user = resul[i].split("|")[0]
      limite = resul[i].split("|")[1]
      tempo = resul[i].split("|")[2]
      obj = {
        user,
        limite,
        tempo
      }
      info.push(obj)
    }
    res.status(200)
    res.json({msg: "sucesso", info})
    return
  })
  } catch (e) {
    console.log(e)
    res.status(500)
    res.json({msg: "Ocorreu um erro ao processar a solicitacao "})
    return
  }
})
app.post("/speed", async (req, res) => {
  exec(`cat /etc/passwd | awk -F : '$3 >= 1000 {print $1}' | grep -v nobody | grep -v ubuntu | grep -v root | grep -v opc | grep -v snap_daemon > usuarios.txt`)
  try {
  var {token} = req.body
  if(!token) {
    res.status(400)
    res.json({msg: "Cade o token?"})
    return
  }
  if(token != rtoken) {
    res.status(403)
    res.json({msg: "token invalido"})
    return
  }
  
  exec("bash ./src/speed.sh", (error, stdout, stderr) => {
    if(error) {
      console.log(error)
      res.status(500)
      res.json({msg: "erro"})
      return
    }
    if(stderr) {
      console.log(stderr)
      res.status(500)
      res.json({msg: "erro"})
      return
    }
    info = stdout.split("|")[0]
    link = stdout.split("|")[1].replace(/\n/g, "")
    
    res.status(200)
    res.json({msg: "sucesso", info, link})
    return
  })
  } catch (e) {
    console.log(e)
    res.status(500)
    res.json({msg: "Ocorreu um erro ao processar a solicitacao "})
    return
  }
})
app.post("/backup", async (req, res) => {
  exec(`cat /etc/passwd | awk -F : '$3 >= 1000 {print $1}' | grep -v nobody | grep -v ubuntu | grep -v root | grep -v opc | grep -v snap_daemon > usuarios.txt`)
  try {
  var {token} = req.body
  if(!token) {
    res.status(400)
    res.json({msg: "Cade o token?"})
    return
  }
  if(token != rtoken) {
    res.status(403)
    res.json({msg: "token invalido"})
    return
  }
  
  exec("bash ./src/bakcupusers.sh", (error, stdout, stderr) => {
    if(error) {
      console.log(error)
      res.status(500)
      res.json({msg: "erro", one: "one"})
      return
    }
    if(stderr) {
      console.log(stderr)
      //res.status(500)
      //res.json({msg: "erro", two: "two"})
      res.status(200)
      if(fs.existsSync("/opt/DragonCore/menu.php")) {
      res.header('Content-disposition', `attachment; filename=dragoncoressh.json`)
      res.sendFile("/root/dragoncoressh.json")
      return
      }
      res.header('Content-disposition', `attachment; filename=backup.vps`)
      res.sendFile(__dirname+"/backup.vps")
      return
    }
    
    res.status(200)
    if(fs.existsSync("/opt/DragonCore/menu.php")) {
    res.header('Content-disposition', `attachment; filename=dragoncoressh.json`)
    res.sendFile("/root/dragoncoressh.json")
    return
    }
    res.header('Content-disposition', `attachment; filename=backup.vps`)
    res.sendFile(__dirname+"/backup.vps")
    return
  })
  } catch (e) {
    console.log(e)
    res.status(500)
    res.json({msg: "Ocorreu um erro ao processar a solicitacao "})
    return
  }
})
app.get("/script", (req, res) => {
  exec(`cat /etc/passwd | awk -F : '$3 >= 1000 {print $1}' | grep -v nobody | grep -v ubuntu | grep -v root | grep -v opc | grep -v snap_daemon > usuarios.txt`)
  if(fs.existsSync("/opt/DragonCore/menu.php")) {
    res.json({type: "dragoncore"})
  } else {
    res.json({type: "sshplus"})
  }
})
async function atu() {
  await delay(2)
  exec(`cat /etc/passwd | awk -F : '$3 >= 1000 {print $1}' | grep -v nobody | grep -v ubuntu | grep -v root | grep -v opc | grep -v snap_daemon > usuarios.txt`)
}