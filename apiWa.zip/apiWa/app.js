const express = require("express")
const morgan = require("morgan")
const {dados} = require("./dados")
const { exec } = require('child_process')
const app = express()
port = dados.porta

app.use(morgan("dev"))
app.listen(port, () => {
  console.log("Api rodando na porta "+port)
})

app.get("/", (req, res) => {
  res.status(200)
  res.json({msg: "online"})
})
app.get("/criarlogin", async (req, res) => {
  try {
  var {user} = req.query
  var {senha} = req.query
  if(!user) {
    res.status(400)
    res.json({msg: "Cade o user?"})
    return
  }
  if(!senha) {
    res.status(400)
    res.json({msg: "Cade a senha?"})
    return
  }
  exec(`sh ./src/user.sh ${user} ${senha}`)
  res.status(200)
  res.json({msg: "sucesso"})
  } catch (e) {
    console.log(e)
    res.status(500)
    res.json({msg: "Ocorreu um erro ao processar a solicitacao"})
    return
  }
})
app.get("/criarteste", async (req, res) => {
  try {
  var {user} = req.query
  var {temp} = req.query
  if(!user) {
    res.status(400)
    res.json({msg: "Cade o user?"})
    return
  }
  if(!temp) {
    res.status(400)
    res.json({msg: "Cade o tempo em min?"})
    return
  }
  exec(`sh ./src/teste.sh ${user} ${temp}`)
  res.status(200)
  res.json({msg: "sucesso"})
  } catch (e) {
    console.log(e)
    res.status(500)
    res.json({msg: "Ocorreu um erro ao processar a solicitacao"})
    return
  }
})
app.get("/renovar", async (req, res) => {
  try {
  var {user} = req.query
  var {dias} = req.query
  if(!user) {
    res.status(400)
    res.json({msg: "Cade o user?"})
    return
  }
  if(!dias) {
    res.status(400)
    res.json({msg: "Cade os dias?"})
    return
  }
  exec(`sh ./src/renovar.sh ${user} ${dias}`)
  res.status(200)
  res.json({msg: "sucesso"})
  } catch (e) {
    console.log(e)
    res.status(500)
    res.json({msg: "Ocorreu um erro ao processar a solicitacao "})
    return
  }
})