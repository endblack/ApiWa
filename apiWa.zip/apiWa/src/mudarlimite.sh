#!/bin/bash

usuario=$1
limite=$2
database="/root/usuarios.db"

[[ -e /opt/DragonCore/menu.php ]] && {
php /opt/DragonCore/menu.php uplimit $usuario $limite
exit 0
}
grep -v ^$usuario[[:space:]] /root/usuarios.db >/tmp/a
mv /tmp/a /root/usuarios.db
echo $usuario $limite >>/root/usuarios.db