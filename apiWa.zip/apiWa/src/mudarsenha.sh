#!/bin/bash

usuario=$1
senha=$2

[[ -e /opt/DragonCore/menu.php ]] && {
php /opt/DragonCore/menu.php uppass $usuario $senha
pkill -u $usuario >/dev/null 2>&1
exit 0
}
echo "$usuario:$senha" | chpasswd
echo "$senha" >/etc/SSHPlus/senha/$usuario
[[ $(ps -u $usuario | grep sshd | wc -l) != '0' ]] && pkill -u $usuario >/dev/null 2>&1