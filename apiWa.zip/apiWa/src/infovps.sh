#!/bin/bash

cd $HOME
PTs='/tmp/prts'
_ons=$(ps -x | grep sshd | grep -v root | grep priv | wc -l)
[[ -e /etc/openvpn/openvpn-status.log ]] && _onop=$(grep -c "10.8.0" /etc/openvpn/openvpn-status.log) || _onop="0"
[[ -e /etc/default/dropbear ]] && _drp=$(ps aux | grep dropbear | grep -v grep | wc -l) _ondrp=$(($_drp - 1)) || _ondrp="0"
_on=$(($_ons + $_onop + $_ondrp))
total=$(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody | wc -l)
system=$(cat /etc/issue.net)
uso=$(top -bn1 | awk '/Cpu/ { cpu = "" 100 - $8 "%" }; END { print cpu }')
cpucores=$(grep -c cpu[0-9] /proc/stat)
ram1=$(free -h | grep -i mem | awk {'print $2'})
usoram=$(free -m | awk 'NR==2{printf "%.2f%%\t\t", $3*100/$2 }')
[[ -e /opt/DragonCore/menu.php ]] && total=$(php /opt/DragonCore/menu.php printlim | cat -n | tail -n 1 | awk '{print $1}') || total=$(cat -n /root/usuarios.db | tail -n 1 | awk '{print $1}')
echo -e "SSH: $(grep 'Port' /etc/ssh/sshd_config | cut -d' ' -f2 | grep -v 'no' | xargs)" >$PTs
[[ -e "/etc/stunnel/stunnel.conf" ]] && echo -e "SSL Tunel: $(netstat -nplt | grep 'stunnel' | awk {'print $4'} | cut -d: -f2 | xargs)" >>$PTs
[[ -e "/etc/openvpn/server.conf" ]] && echo -e "Openvpn: $(netstat -nplt | grep 'openvpn' | awk {'print $4'} | cut -d: -f2 | xargs)" >>$PTs
[[ "$(netstat -nplt | grep 'sslh' | wc -l)" != '0' ]] && echo -e "SSlh: $(netstat -nplt | grep 'sslh' | awk {'print $4'} | cut -d: -f2 | xargs)" >>$PTs
[[ "$(netstat -nplt | grep 'squid' | wc -l)" != '0' ]] && echo -e "Squid: $(netstat -nplt | grep 'squid' | awk -F ":" {'print $4'} | xargs)" >>$PTs
[[ "$(netstat -nltp | grep 'dropbear' | wc -l)" != '0' ]] && echo -e "DropBear: $(netstat -nplt | grep 'dropbear' | awk -F ":" {'print $4'} | xargs)" >>$PTs
[[ "$(netstat -nplt | grep 'python' | wc -l)" != '0' ]] && echo -e "Proxy Socks: $(netstat -nplt | grep 'python' | awk {'print $4'} | cut -d: -f2 | xargs)" >>$PTs
info=""
info="=×=×=×=×=×=×=×=×=×=×=×=×=×=\n"
info+="*INFORMACOES DO SERVIDOR*\n"
info+="=×=×=×=×=×=×=×=×=×=×=×=×=×=\n\n"
info+="*SISTEMA OPERACIONAL*\n"
info+="$system\n\n"
info+="*PROCESSADOR*\n"
info+="*Nucleos:* $cpucores\n"
info+="*Ultilizacao:* $uso\n\n"
info+="*MEMORIA RAM*\n"
info+="*Total:* $ram1\n"
info+="*Ultilizacao:* $usoram\n\n"
while read linha; do
info+="*$(echo -e "$linha")*\n"
done < <(cat $PTs)
info+="\n*$total* USUARIOS *$_on* ONLINE"
echo $info