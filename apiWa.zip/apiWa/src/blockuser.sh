#!/bin/bash

usermod -L $1
pkill -f $1