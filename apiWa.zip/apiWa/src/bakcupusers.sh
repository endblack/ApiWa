#!/bin/bash

[[ -e /opt/DragonCore/menu.php ]] && {
php /opt/DragonCore/menu.php createbackup >/dev/null 2>&1
exit 0
}
rm backup.vps 1>/dev/null 2>/dev/null
tar cvf backup.vps /root/usuarios.db /etc/shadow /etc/passwd /etc/group /etc/gshadow /etc/bot /etc/SSHPlus/senha /etc/SSHPlus/v2ray /etc/openvpn $HOME/BOT/permitidos $HOME/BOT/revenda >/dev/null 2>&1