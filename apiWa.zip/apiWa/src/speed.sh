#!/bin/bash

rm -rf speed >/dev/null 2>&1
speedtest --share > speed
png=$(cat speed | sed -n '5 p' | awk -F : {'print $NF'})
down=$(cat speed | sed -n '7 p' | awk -F : {'print $NF'})
upl=$(cat speed | sed -n '9 p' | awk -F : {'print $NF'})
lnk=$(cat speed | sed -n '10 p' | awk {'print $NF'})
msg=""
msg="=×=×=×=×=×=×=×=×=×=×=×=×=×=\n"
msg+="*🚀 VELOCIDADE DO SERVIDOR 🚀*\n"
msg+="=×=×=×=×=×=×=×=×=×=×=×=×=×=\n\n"
msg+="*PING/LATENCIA:*$png\n"
msg+="*DOWNLOAD:*$down\n"
msg+="*UPLOAD:*$upl\n"
echo "$msg|$lnk"
rm -rf speed >/dev/null 2>&1