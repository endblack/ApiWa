#!/bin/bash

usuario=$1
dias=$2
inputdate=$dias

udata=$(date "+%d/%m/%Y" -d "+$inputdate days")
sysdate="$(echo "$udata" | awk -v FS=/ -v OFS=- '{print $3,$2,$1}')"
chage -E $sysdate $usuario