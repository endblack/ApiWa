#!/bin/bash

[[ -e /opt/DragonCore/menu.php ]] && {
info=""
for user in $(cat /etc/passwd | awk -F : '$3 >= 1000 {print $1}' | grep -v nobody | grep -v ubuntu | grep -v root | grep -v opc | grep -v snap_daemon); do
info=''
senha=$(php /opt/DragonCore/menu.php printpass2 $user | cut -d'|' -f2 | cut -d' ' -f2)
limite=$(php /opt/DragonCore/menu.php printlim2 $user | cut -d'|' -f2 | cut -d' ' -f2)
datauser=$(chage -l $user | grep -i co | awk -F : '{print $2}')
[[ $datauser = ' never' ]] && {
data="00/00/00"
} || {
databr="$(date -d "$datauser" +"%Y%m%d")"
hoje="$(date -d today +"%Y%m%d")"
[[ $hoje -ge $databr ]] && {
data="Venceu"
} || {
dat="$(date -d"$datauser" '+%Y-%m-%d')"
data=$(echo -e "$((($(date -ud $dat +%s) - $(date -ud $(date +%Y-%m-%d) +%s)) / 86400)) DIAS")
}
}
info+="$user|$senha|$limite|$data#"
echo $info
done
exit 0
}
info=""
for user in $(cat /etc/passwd | awk -F : '$3 >= 1000 {print $1}' | grep -v nobody | grep -v ubuntu | grep -v root | grep -v opc | grep -v snap_daemon); do
 info=''
 [[ -e /etc/SSHPlus/senha/$user ]] && senha=$(cat /etc/SSHPlus/senha/$user) || senha='Null'
 [[ $(grep -wc $user $HOME/usuarios.db) != '0' ]] && limite=$(grep -w $user $HOME/usuarios.db | cut -d' ' -f2) || limite='Null'
 datauser=$(chage -l $user | grep -i co | awk -F : '{print $2}')
 [[ $datauser = ' never' ]] && {
 data="00/00/00"
 } || {
 databr="$(date -d "$datauser" +"%Y%m%d")"
 hoje="$(date -d today +"%Y%m%d")"
 [[ $hoje -ge $databr ]] && {
 data="Venceu"
 } || {
 dat="$(date -d"$datauser" '+%Y-%m-%d')"
 data=$(echo -e "$((($(date -ud $dat +%s) - $(date -ud $(date +%Y-%m-%d) +%s)) / 86400)) DIAS")
 }
 }
 info+="$user|$senha|$limite|$data#"
 echo $info
done