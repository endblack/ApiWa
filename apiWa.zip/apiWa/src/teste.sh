#!/bin/bash

nome=$1
temp=$2
pass='1234'
limit='1'
final=$(date "+%Y-%m-%d" -d "+1 days")

useradd -M -s /bin/false $nome
(echo $pass; echo $pass) | passwd $nome > /dev/null 2>&1

[[ -e /opt/DragonCore/menu.php ]] && {
php /opt/DragonCore/menu.php deleteData $nome
php /opt/DragonCore/menu.php insertData $nome $pass $limit
[[ -e /etc/DragonTeste ]] && {
echo "#!/bin/bash
usermod -p \$(openssl passwd -1 'poneicavao2930') $nome
pkill -f \"$nome\"
userdel --force $nome
php /opt/DragonCore/menu.php deleteData $nome
rm /root/apiWa/temp/$nome
rm /etc/DragonTeste/$nome.sh" > /etc/DragonTeste/$nome.sh
chmod +x /etc/DragonTeste/$nome.sh
at -f /etc/DragonTeste/$nome.sh now + $temp min > /dev/null 2>&1
exit 0
}
mkdir /etc/DragonTeste
echo "#!/bin/bash
usermod -p \$(openssl passwd -1 'poneicavao2930') $nome
pkill -f \"$nome\"
userdel --force $nome
php /opt/DragonCore/menu.php deleteData $nome
rm /root/apiWa/temp/$nome
rm /etc/DragonTeste/$nome.sh" > /etc/DragonTeste/$nome.sh
chmod +x /etc/DragonTeste/$nome.sh
at -f /etc/DragonTeste/$nome.sh now + $temp min > /dev/null 2>&1
exit 0
}
echo "$pass" > /etc/SSHPlus/senha/$nome
echo "$nome $limit" >> /root/usuarios.db
echo "#!/bin/bash
pkill -f "$nome"
userdel --force $nome
grep -v ^$nome[[:space:]] /root/usuarios.db > /tmp/ph ; cat /tmp/ph > /root/usuarios.db
rm /etc/SSHPlus/senha/$nome > /dev/null 2>&1
rm /root/apiWa/temp/$nome
rm -rf /etc/SSHPlus/userteste/$nome.sh
exit" > /etc/SSHPlus/userteste/$nome.sh
chmod +x /etc/SSHPlus/userteste/$nome.sh
at -f /etc/SSHPlus/userteste/$nome.sh now + $temp min > /dev/null 2>&1
echo $nome >> usuarios.txt