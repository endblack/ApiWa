#!/bin/bash

usuario=$1

[[ -e /opt/DragonCore/menu.php ]] && {
piduser=$(ps -u "$usuario" | grep sshd | cut -d? -f1)
kill -9 $piduser >/dev/null 2>&1
php /opt/DragonCore/menu.php deluser $usuario
exit 0
}
piduser=$(ps -u "$usuario" | grep sshd | cut -d? -f1)
kill -9 $piduser >/dev/null 2>&1
userdel --force "$usuario" 2>/dev/null
grep -v ^$usuario[[:space:]] /root/usuarios.db >/tmp/ph
cat /tmp/ph >/root/usuarios.db
rm /etc/SSHPlus/senha/$usuario >/dev/null 2>&1