#!/bin/bash
 
 
[[ -e /opt/DragonCore/menu.php ]] && {
info2=""
for user in $(cat /etc/passwd | awk -F : '$3 >= 1000 {print $1}' | grep -v nobody); do
 [[ "$(php /opt/DragonCore/menu.php printlim | grep -w $user)" != "0" ]] && lim="$(php /opt/DragonCore/menu.php printlim | grep -w Gama | cut -d'|' -f2 | cut -d' ' -f2)" || lim=0
 [[ $(netstat -nltp | grep 'dropbear' | wc -l) != '0' ]] && drop="$(fun_drop | grep "$user" | wc -l)" || drop=0
 [[ -e /etc/openvpn/openvpn-status.log ]] && ovp="$(cat /etc/openvpn/openvpn-status.log | grep -E ,"$user", | wc -l)" || ovp=0
 sqd="$(ps -u $user | grep sshd | wc -l)"
 _cont=$(($drop + $ovp))
 conex=$(($_cont + $sqd))
 [[ $conex -gt '0' ]] && {
 timerr="$(ps -o etime $(ps -u $user | grep sshd | awk 'NR==1 {print $1}') | awk 'NR==2 {print $1}')"
 #info2+="===========================\n"
 #info2+="🟢 $user       $conex/$lim       ⏳$timerr\n"
 info2+="$user|$conex/$lim|$timerr#"
 }
done
echo $info2
exit 0
}
database="/root/usuarios.db"
info2=""
for user in $(cat /etc/passwd | awk -F : '$3 >= 1000 {print $1}' | grep -v nobody); do
 [[ "$(grep -w $user $database)" != "0" ]] && lim="$(grep -w $user $database | cut -d' ' -f2)" || lim=0
 [[ $(netstat -nltp | grep 'dropbear' | wc -l) != '0' ]] && drop="$(fun_drop | grep "$user" | wc -l)" || drop=0
 [[ -e /etc/openvpn/openvpn-status.log ]] && ovp="$(cat /etc/openvpn/openvpn-status.log | grep -E ,"$user", | wc -l)" || ovp=0
 sqd="$(ps -u $user | grep sshd | wc -l)"
 _cont=$(($drop + $ovp))
 conex=$(($_cont + $sqd))
 [[ $conex -gt '0' ]] && {
 timerr="$(ps -o etime $(ps -u $user | grep sshd | awk 'NR==1 {print $1}') | awk 'NR==2 {print $1}')"
 #info2+="===========================\n"
 #info2+="🟢 $user       $conex/$lim       ⏳$timerr\n"
 info2+="$user|$conex/$lim|$timerr#"
 }
done
echo $info2