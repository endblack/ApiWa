dados = {
  porta: 5000 //Porta que a api vai rodar
}
module.exports = {
  dados
}